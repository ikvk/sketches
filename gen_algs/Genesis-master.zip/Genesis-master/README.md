## About

Cenesis - life simulator on PC (Java)

HOW TO START:   
Download and run this file:
```
Genesis.jar
```

If you have not Java, can install it here https://www.java.com/download/
